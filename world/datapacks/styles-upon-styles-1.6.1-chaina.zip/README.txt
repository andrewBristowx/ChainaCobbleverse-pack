Thank you for downloading my pack! This one adds costumes to a variety of Pokemon.

To change outfits, use the following items:

Dark Suit Style Absol: Luxury Ball
Ash Ketchum Style Riolu & Lucario: Poke Ball
Piers Style Obstagoon: Throat Spray
Hero Style Greninja: Green Apricorn
Assault Style Feraligatr: Assault Vest
Samurai Style Skarmory: Heavy Ball
Lethal League Style Krookodile: Clay Ball
Punk Style Blaziken: Leather
Starry Sky Espeon: Glowstone Dust
Onion Knight Sirfetch'd: Medicinal Leek
Sygna Style Sneasel/Weavile: Gray Wool
Super Suit Style Charmander/Charmeleon/Charizard: Blue Banner
Neo Guardian Style Gible/Gabite/Garchomp: Redstone
Antique Purple Absol: Purple Wool
Sea Captain Lapras: Spyglass
New Years Electivire: Yellow Wool
Rowdy Crew Totodile/Croconaw/Feraligatr: Spyglass
Sygna Suit Lugia: Light Blue Wool
Starry Sky Umbreon: Glowstone Dust
Sailor Floatzel: Spyglass
Aarune Flygon: Red Wool
Punk Obstagoon: Leather
Sygna Suit Latios: Blue Wool
Champion Meowscarda: Gold Nugget
Casual Poliwrath: Pink Wool
Starry Sky Zoroark: Glowstone Dust
Armored Mew: Iron Helmet/Chestplate/Leggings/Boots
Explorer Infernape: Wooden/Iron/Golden/Diamond/Netherite Pickaxe
Champion Dragonite: Punching Glove
Starry Sky Eevee: Glowstone Dust
Noble Style Armarouge: Blue Wool
Fairy-Tale Stylee Espeon: Golden Apple
Casual Politoed: Pink Wool
Wizard Dragonite: Diamond
Knight Gallade: Iron Helmet/Chestplate/Leggings/Boots
Horse Armor Mudsdale: Any Horse Armor
Zelda Gardevoir: Pink Dye
Dark Lord Style Mewtwo: Black Wool
Dark Lord Style Mewtwo (Velvet Rose): Red Wool

***SUMMER UPDATE***

Every Pokemon in this group uses a melon slice.

Summer Ninetales
Summer Fun Jigglypuff
Summer Zubat
Summer Psyduck/Golduck
Lifeguard Arcanine
Beach Style Machamp
Beach Style Munchlax/Snorlax
Hula Kirlia
Summer Plusle
Summer Minun
Floatie Fun Piplup
Summer Prinplup/Empoleon
Surf's Up Floatzel
Summer Lopunny
Lifeguard Lucario
Summer Zoroark
Beach Vibes Dedenne
Beach Style Meowscarada

Dark Suit Style Absol by Dylanteteras.
Ash Ketchum Style Riolu/Lucario, Piers Style Obstagoon, Assault Style Feraligatr, Samurai Style Skarmory, Super Suit Style Charmander/Charmeleon/Charizard, Neo Guardian Style Gible/Gabite/Garchomp, New Year's Electivire, Lethal League Style Krookodile, Rowdy Crew Feraligatr and Punk Obstagoon outfits by Rainova.
Punk Style Blaziken, Starry Sky Espeon, Sygna Suit Lugia, Starry Sky Umbreon, Sailor Floatzel, Champion Dragonite and Starry Sky Eevee by toyota325.
Hero Style Greninja, Onion Knight Sirfetch'd and Sygna Style Sneasel/Weavile by juano_204.
Antique Purple Absol and Sea Captain Lapras by Gigadeng.
Aarune Flygon and Sygna Suit Latios by CarnivalRich.
Starry Sky Zoroark, Armored Mew and Explorer Infernape by frostyzl.
Noble Style Armarouge, Summer Vibes Jigglypuff, Summer Zubat, Summer Psyduck/Golduck, Lifeguard Arcanine, Beach Style Machamp, Beach Style Munchlax/Snorlax, Hula Kirlia, Summer Plusle, Summer Minun, Floatie Fun Piplup, Summer Prinplup/Empoleon, Surf's Up Floatzel, Summer Lopunny, Lifeguard Lucario, Summer Zoroark, Beach Vibes Dedenne, Zeldaa Gardevoir, and Dark Lord Style Mewtwo (normal and Red Velvet) by Muddiemodels.
Summer Ninetales by MF_NO1R.
Casual Poliwrath, Champion Meowscarada, Fairy-Tale Espeon and Casual Politoed by ririsodizzy.
Wizard Dragonite, Knight Gallade and Horse Armor Mudsdale: zckxz
Rowdy Crew Totodile/Croconaw: Aquiraa

To install the pack, make sure to copy the zip file to both the resourcepacks folder in your Minecraft instance and in the datapacks folder in your world's save data. Once installed, place the mod at the top of the load order. This pack will only work on Cobblemon 1.7 or above.

Please make sure to credit myself and all individuals involved in the creation of this pack before using it in your own datapack.